<?php
//000000000030
 exit();?>
think_serialize:a:7:{s:2:"id";i:31;s:4:"node";s:14:"admin/menu/add";s:5:"title";s:12:"添加菜单";s:7:"is_menu";i:1;s:7:"is_auth";i:1;s:8:"is_login";i:1;s:9:"create_at";s:19:"2018-05-04 11:09:55";}